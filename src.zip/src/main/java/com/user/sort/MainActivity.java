package com.user.sort;

import android.app.*;
import android.os.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.View;
import android.R.integer;
import java.util.Random;
import java.util.ArrayList;
import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import com.user.sort.SortHelper;
import android.graphics.Color;
import android.widget.TextView;

public class MainActivity extends Activity {
    ArrayList<Integer> list = new ArrayList<>(); //容器
    public static final int QUANTITY = 40; //数量
    public static final long TIME_INTERVAL = 100; //时间间隔ms
    public static final int MAX_VALUE = 150; //最大数
    LinearLayout linear_layout; //视图
    ArrayList<View> list_view = new ArrayList<>(); //视图容器
    boolean is = false; //控制是否能新建线程
    SortHelper sortHelper = new SortHelper(this); //创建排序类
    int max_height; //记录最高像素
    TextView text;
    TextView time_text;
    
    public static int step = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Button start_btn = findViewById(R.id.start_btn);
        text = findViewById(R.id.text);
        time_text = findViewById(R.id.time_text);
        linear_layout = findViewById(R.id.linear_layout);
        max_height =(int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, MAX_VALUE, getResources().getDisplayMetrics());
        
        //开始按钮
        start_btn.setOnClickListener(v->{
            
            if(!is){
                step = 0;
                ClearRes(); //清空
                PutNum(); //随机放入
                VisualSort();//可视化
            
                int[] array = new int[list.size()];
                for (int i = 0; i < list.size(); i++) {
                    array[i] = list.get(i);
                }
                
                //开始线程
                new Thread(() -> {is=true;SortFun(array);is=false;}).start();
            }
                
        });
    }
    
    //排序方法
    private void SortFun(int[] arr){
        long start_time = System.currentTimeMillis();
        //冒泡排序
        //sortHelper.bubbling(arr);
        //选择排序
        sortHelper.Select(arr);
        //递归排序
        //sortHelper.recursion(arr, 0, arr.length-1);
        long end_time = System.currentTimeMillis();
        runOnUiThread(() ->time_text.setText("时间："+(end_time-start_time)/1000+"s") );
        
    }
    
    // 可视化方法
    private void VisualSort(){
        for(View view : list_view) {
            linear_layout.addView(view);
        }
    }
    
    // 放入数方法
    private void PutNum(){
        Random r = new Random();
        for(int i=0;i<QUANTITY;++i){
            list.add(r.nextInt(MAX_VALUE)+1);
            list_view.add(CreateView(list.get(i),i));  //添加值
        }
    }
    
    
    
    //创建视图
    private View CreateView(int value,int id){
        View view = new View(this);
        
        int height =(max_height*2 < linear_layout.getHeight()) ? (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value*2, getResources().getDisplayMetrics()) : (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
        
        // 准备 View 的布局参数
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                0, // width 0dp, 因为我们将使用 weight
                height
        );
        layoutParams.gravity = Gravity.BOTTOM; // 设置为底部对齐
        layoutParams.weight = 1; // 设置 weight 为 1
        
        int viewWidth = linear_layout.getWidth()/QUANTITY/5; //左右间距值
        
        layoutParams.leftMargin = viewWidth; //左间距
        layoutParams.rightMargin = viewWidth; //右间距

        // 设置 View 的背景颜色
        view.setBackgroundColor(Color.parseColor("#FBCC0C")); //视图背景色

        // 应用布局参数到 View
        view.setLayoutParams(layoutParams); //应用布局
        
        return view;
    }
    
    //清空资源方法
    private void ClearRes() {
        if(!list.isEmpty())list.clear(); //清空数组
        // 清空布局
        linear_layout.removeAllViews(); // 清空视图
        if(!list_view.isEmpty())list_view.clear(); //清空布局数组
    }
    
    //刷新视图
    public void Visualize(int[] arr) {
        runOnUiThread(() -> text.setText("步："+step++));
        for (int i = 0; i < arr.length; i++) {
            View view = list_view.get(i);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) view.getLayoutParams();
            
            int height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, arr[i], getResources().getDisplayMetrics());
            layoutParams.height = (max_height*2 < linear_layout.getHeight()) ? height*2 : height;
            view.setLayoutParams(layoutParams);
        }
    }
}