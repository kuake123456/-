package com.user.sort;

import com.user.sort.MainActivity;
public class SortHelper{
    
    private MainActivity m;
    
    SortHelper(MainActivity m){
        this.m = m;
    }
    //-------------------------排序算法-----------------------------------------
    
    //冒泡排序
    public void bubbling(int[] arr){
        for(int i=0;i<arr.length-1;i++){
            for(int j=0;j<arr.length-1-i;j++){
                if(arr[j]>arr[j+1]){
                   int g=arr[j]; 
                   arr[j]=arr[j+1]; 
                   arr[j+1]=g; 
                   m.runOnUiThread(() -> m.Visualize(arr)); // 更新视图
                   try { Thread.sleep(MainActivity.TIME_INTERVAL,100000); } catch (InterruptedException e) { e.printStackTrace(); } //间隔时间ms
                }       
            }
        }
    }
    
    //选择排序
    public void Select(int[] arr){
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr.length;j++){
                if(arr[i]<arr[j]){
                   int g=arr[i];
                   arr[i]=arr[j];
                   arr[j]=g;
                   m.runOnUiThread(() -> m.Visualize(arr)); // 更新视图
                   try { Thread.sleep(MainActivity.TIME_INTERVAL); } catch (InterruptedException e) { e.printStackTrace(); } //间隔时间ms
              }
            }
        }
    }
    
    //递归排序
    public void recursion(int[] arr, int start, int end) {
        if (start < end) {
            int partitionIndex = partition(arr, start, end);
            m.runOnUiThread(() -> m.Visualize(arr)); // 更新视图
            try { Thread.sleep(MainActivity.TIME_INTERVAL); } catch (InterruptedException e) { e.printStackTrace(); }
            recursion(arr, start, partitionIndex - 1);
            recursion(arr, partitionIndex + 1, end);
        }
    }

    private int partition(int[] arr, int start, int end) {
        int pivot = arr[end];
        int i = start - 1;
        for (int j = start; j < end; j++) {
            if (arr[j] < pivot) {
                i++;
                // 交换 arr[i] 和 arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                m.runOnUiThread(() -> m.Visualize(arr)); // 更新视图
                try { Thread.sleep(MainActivity.TIME_INTERVAL); } catch (InterruptedException e) { e.printStackTrace(); }
            }
        }
        // 交换 arr[i+1] 和 arr[end]
        int temp = arr[i + 1];
        arr[i + 1] = arr[end];
        arr[end] = temp;
        m.runOnUiThread(() -> m.Visualize(arr)); // 更新视图
        try { Thread.sleep(MainActivity.TIME_INTERVAL); } catch (InterruptedException e) { e.printStackTrace(); }
        return i + 1;
    }
}